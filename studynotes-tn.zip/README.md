# 📚 StudyNotes TN - தமிழ்நாடு பள்ளி மாணவர்களுக்கான முழுமையான இலவச கற்றல் தளம்

A modern, responsive, student-friendly web application tailored for Tamil Nadu State Board (Samacheer Kalvi) students across **Class 6 to Class 12**.

---

## 🌟 முழுமையான பாடங்கள் (100% Subject Coverage)

Website-ல் தமிழ்நாடு பள்ளி கல்வித் துறையின் அனைத்து முக்கிய பாடங்களும் முழுமையான அத்தியாயங்கள், சூத்திரங்கள் மற்றும் வினாத்தாள்களுடன் சேர்க்கப்பட்டுள்ளன:

1. ⚛️ **Physics (இயற்பியல்)** - Electrostatics, Current Electricity, Magnetism, Optics, Dual Nature, Semiconductors, Derivations & Formulas (Classes 11 & 12).
2. 🧪 **Chemistry (வேதியியல்)** - Metallurgy, p-Block Elements, Coordination Chemistry, Chemical Kinetics, Hydroxy Compounds & Named Reactions (Classes 11 & 12).
3. 💻 **Computer Science (கணினி அறிவியல்)** - Python Programming, Functions, Algorithmic Strategies, OOPs, SQL Databases & Web Integration (Classes 11 & 12).
4. 📐 **Mathematics (கணிதம்)** - Relations & Functions, Sequences, Algebra, Geometry, Coordinate Geometry, Trigonometry, Mensuration, Statistics, Matrices, Vectors, Calculus (Classes 6 to 12).
5. 🧬 **Biology (உயிரியல்)** - Botany & Zoology, Plant Anatomy, Human Reproduction, Genetics & Diagrams (Classes 11 & 12).
6. 📕 **தமிழ் (Tamil)** - இயல் வாரியான உரைநடை உலகம், செய்யுள் (கவிதைப்பேழை), துணைப்பாடம், இலக்கணம் & மனப்பாடப் பகுதிகள் (Classes 6 to 12).
7. 📘 **English (ஆங்கிலம்)** - Unit-wise Prose, Poetry, Supplementary, Grammar Rules, Vocabulary, Notice & Letter Writing (Classes 6 to 12).
8. 🔬 **Science (அறிவியல்)** - Classes 6 to 10 முழுமையான Physics, Chemistry & Biology ஒருங்கிணைந்த பாடங்கள்.
9. 🌍 **Social Science (சமூக அறிவியல்)** - History, Geography, Civics & Economics with Timelines & Maps (Classes 6 to 10).
10. 📊 **Commerce & Accountancy (வணிகவியல் & கணக்குப்பதிவியல்)** - Principles of Management, Financial Markets & Accounts (Classes 11 & 12).

---

## 🏆 ஒவ்வொரு பாடத்திலும் அடங்கியுள்ளவை (Features Per Subject)

- **Chapter-wise Notes (பாடக் குறிப்புகள்)**:
  - சுருக்கமான பாட விளக்கம் (Summary), முக்கிய குறிப்புகள் (High-yield points) & சூத்திரங்கள் (Formulas).
  - **Download PDF button**: அச்சிடக்கூடிய (Print-ready) நேரடி PDF கோப்பு உருவாக்கம்.
  - **Quick Read modal**: கவனச்சிதறல் இல்லாத தனி வாசிப்புத் திரை.
  - **Bookmark button**: கடைசி நேர திருப்புதலுக்கு குறிப்புகளைச் சேமிக்கும் வசதி.
- **Previous Year Question Papers (2019 - 2025)**:
  - **2025 Model, 2024 Public, 2023 Public, 2022 Public, 2021 PTA Question Bank, 2020 DGE Bank, 2019 Benchmark**.
  - **Question Paper PDF** மற்றும் **Official Scoring Answer Key PDF** பதிவிறக்க பொத்தான்கள்.
  - "Download All (2019-2025)" முழு வினாத்தாள் தொகுப்பு பதிவிறக்கம்.
- **Important Questions (முக்கிய வினாக்கள்)**:
  - **2 மதிப்பெண், 3 மதிப்பெண், 5 மதிப்பெண் மற்றும் 8 மதிப்பெண்** வினாக்கள்.
  - **⭐ Golden Question** பேட்ஜ்கள் (அரசு பொதுத்தேர்வில் அதிக முறை கேட்கப்பட்ட வினாக்கள்).
  - "View Solution Hint" மூலம் தேர்வுத்தாளில் விடை எழுதும் படிநிலைகள் (Step-marking scheme).
- **Syllabus & Blueprint (பாடத்திட்டம் & புளூபிரிண்ட்)**:
  - TN SCERT அதிகாரப்பூர்வ மதிப்பெண் பங்கீடு மற்றும் பாடத்திட்ட PDF.

---

## 🚀 இணையதளத்தைத் திறப்பது எப்படி?

நேரடியாக உங்கள் கணினியில் பிரவுசரில் [index.html](file:///C:/Users/vishn/.gemini/antigravity/scratch/studynotes-tn/index.html) கோப்பை திறந்து பயன்படுத்தலாம்!
```text
C:\Users\vishn\.gemini\antigravity\scratch\studynotes-tn\index.html
```
